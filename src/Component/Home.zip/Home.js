import react from 'react';

import homee from '../Assets/Images/homee.jpeg';

const Home = () => {
  return(
    <img src={homee}  style={{height:'88vh' , width: '100%',backgroundSize: 'cover',marginTop:'0px'}} />
  

  )}

  export default Home;